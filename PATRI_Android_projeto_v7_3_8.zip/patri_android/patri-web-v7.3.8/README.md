# PATRI v7.3 — Offline Core

- IndexedDB passa a manter uma cópia local do estado do PATRI.
- localStorage continua como camada de compatibilidade/recuperação.
- Alterações offline ficam pendentes e são sincronizadas quando a conexão retorna.
- A sincronização compara o timestamp local com o `updated_at` da nuvem para evitar sobrescrever uma alteração local mais recente.
- Supabase continua como nuvem e não houve nova migration.
- Service Worker atualizado para invalidar o cache anterior.

Validações: JavaScript inline com `node --check` e integridade do ZIP com `unzip -t`.
