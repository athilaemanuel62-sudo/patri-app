// Configuração pública do projeto Supabase.
window.SUPABASE_URL = 'https://yeygkoaehdzrqwhkwhtg.supabase.co';
window.SUPABASE_ANON_KEY = 'sb_publishable_5oXOOwio8uQkL_o3hco7Gg_NPRFHNXx';
