# PATRI Android — projeto base

Este projeto empacota o PATRI PWA como Android Trusted Web Activity (TWA), preservando o PATRI Web como fonte única.

## URL atual
https://admgestao.netlify.app/

## Como gerar o APK
1. Abra esta pasta no Android Studio.
2. Aguarde o Gradle sincronizar.
3. Use Build > Build APK(s).
4. Para publicação, configure uma chave de assinatura própria.

## Associação do domínio (necessária para TWA em modo standalone)
Depois de criar a chave de assinatura, obtenha sua impressão SHA-256 e substitua o placeholder em:
`netlify/.well-known/assetlinks.json`

Publique esse arquivo no site em:
`https://admgestao.netlify.app/.well-known/assetlinks.json`

O package name é `br.com.patri.app`.

## Observação
O ambiente desta conversa não possui o Android SDK/Build Tools necessários para produzir e assinar o APK final. Este pacote é o projeto Android pronto para compilação no Android Studio.
