package br.com.patri.app;

import android.app.Activity;
import android.os.Bundle;
import android.net.Uri;
import androidx.browser.customtabs.CustomTabsCallback;
import androidx.browser.customtabs.CustomTabsClient;
import androidx.browser.customtabs.CustomTabsIntent;
import androidx.browser.customtabs.CustomTabsServiceConnection;
import androidx.browser.customtabs.CustomTabsSession;
import androidx.browser.trusted.TrustedWebActivityIntentBuilder;

public class MainActivity extends Activity {
    private static final String START_URL = "https://admgestao.netlify.app/";
    private CustomTabsClient client;
    private CustomTabsSession session;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        launchPatri();
    }

    private void launchPatri() {
        CustomTabsClient.bindCustomTabsService(this, "com.android.chrome", new CustomTabsServiceConnection() {
            @Override public void onCustomTabsServiceConnected(android.content.ComponentName name, CustomTabsClient c) {
                client = c;
                client.warmup(0L);
                session = client.newSession(new CustomTabsCallback());
                openTwa();
            }
            @Override public void onServiceDisconnected(android.content.ComponentName name) { client = null; session = null; }
        });
    }

    private void openTwa() {
        try {
            new TrustedWebActivityIntentBuilder(Uri.parse(START_URL))
                    .setScreenOrientation(androidx.browser.trusted.ScreenOrientation.PORTRAIT)
                    .build(session)
                    .launchTrustedWebActivity(this);
        } catch (Exception e) {
            CustomTabsIntent intent = new CustomTabsIntent.Builder(session).build();
            intent.launchUrl(this, Uri.parse(START_URL));
        }
    }
}
